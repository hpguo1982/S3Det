import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('ultralytics/cfg/models/s3det.yaml')
    model.val(data='',
              split='',
              imgsz=640,
              batch=16,
              )